// Copyright 2022 Graph Of Dream 626 (Baup626). All Rights Reserved.

using UnrealBuildTool;
using System.IO;

public class ComfortableCpu : ModuleRules
{
  public ComfortableCpu(ReadOnlyTargetRules Target) : base(Target)
  {
    PrivateDependencyModuleNames.AddRange(
      new string[]
      {
        "Core",
        "CoreUObject",
        "Engine"
      }
      );

    PublicSystemLibraries.Add("ntdll.lib");
    PublicAdditionalLibraries.Add(Path.Combine(ModuleDirectory, "..", "..", "ThirdParty", "baup626cc5.lib"));
  }
}
