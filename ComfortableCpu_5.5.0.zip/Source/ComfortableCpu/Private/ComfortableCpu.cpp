// Copyright 2022 Graph Of Dream 626 (Baup626). All Rights Reserved.

// Fix the update frequency here by need, default is 3 seconds
#define G6_DEF_UpdateFrequency 3 

#include "ComfortableCpu.h"
#include "Tickable.h"
#include "Engine/UserDefinedEnum.h"

#define LOCTEXT_NAMESPACE "FComfortableCpuModule"
bool G6_API_UpdateUE5CpuUsage(int cpuCount, int reserve);

class CpuManager : public FTickableGameObject
{
public:

	CpuManager()
	{
		mCpuCoreNumber = 0;
		mTimeLapse = 0;
	}

	virtual TStatId GetStatId() const override 
	{ RETURN_QUICK_DECLARE_CYCLE_STAT(CpuManager, STATGROUP_Tickables); }

	virtual bool IsTickableWhenPaused() const
	{ return true; }

	virtual bool IsTickableInEditor() const
	{ return true; }

	virtual void Tick(float DeltaTime)
	{
		if (mCpuCoreNumber <= 0)
			return;
		if (mTimeLapse > G6_DEF_UpdateFrequency)
		{
			G6_API_UpdateUE5CpuUsage(mCpuCoreNumber, 626);
			mTimeLapse = 0;
		}
		mTimeLapse += DeltaTime;
	}
	static CpuManager* instance;
	int32 mCpuCoreNumber;
	float mTimeLapse;
};

CpuManager* CpuManager::instance = 0;

void FComfortableCpuModule::StartupModule()
{
	UUserDefinedEnum* uUserDefinedEnum1 = 0;
	uUserDefinedEnum1 = Cast<UUserDefinedEnum>(StaticLoadObject(UUserDefinedEnum::StaticClass(), NULL, TEXT("/ComfortableCpu/Config")));
	if (!uUserDefinedEnum1)
		return;
	FText value1 = uUserDefinedEnum1->GetDisplayNameTextByIndex(0);
	FString value2 = value1.ToString();
	int32 cpuCoreNumber1 = 0;
	TTypeFromString<int32>::FromString(cpuCoreNumber1, *value2);
	if (cpuCoreNumber1 <= 0 || cpuCoreNumber1 > 64)
		return;
	CpuManager::instance = new CpuManager();
	CpuManager::instance->mCpuCoreNumber = cpuCoreNumber1;
}

void FComfortableCpuModule::ShutdownModule()
{
	if (CpuManager::instance)
	{
		delete CpuManager::instance;
		CpuManager::instance = 0;
	}
}

#undef LOCTEXT_NAMESPACE
IMPLEMENT_MODULE(FComfortableCpuModule, ComfortableCpu)

